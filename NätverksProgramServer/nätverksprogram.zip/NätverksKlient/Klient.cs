﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace NätverksKlient
{
    public partial class Klient : Form
    {
        TcpClient klient = new TcpClient();
        public Klient()
        {
            InitializeComponent();
            
            btnSendFile.Enabled = false;
            btnTaEmot.Enabled = false;
            klient.NoDelay = false;
        }
       
        public async void Connect()
        {
            IPAddress adress = IPAddress.Parse(tbxIP.Text);
            //int port = int.Parse(tbxport.Text);

            try
            {
                await klient.ConnectAsync(adress, 12345);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Kunde inte ansluta"); return;
            }
            Lyssna();
            
            btnConnect.Enabled = false;
            btnSendFile.Enabled = true;
            btnTaEmot.Enabled = true;
        }

         public async void StartSending ( )
        {
            if ( klient.Connected )
            { 
                  
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    byte[] filData = System.IO.File.ReadAllBytes(openFileDialog1.FileName);
                    
                    byte[] nr = BitConverter.GetBytes(filData.Length);
                    klient.SendBufferSize = filData.Length;
                  //  byte[] testData = new byte[3];
                //string message = "nämen tjena";
                byte[] utData = Encoding.Unicode.GetBytes(openFileDialog1.FileName);
                
                try
                    {
                        byte[] nameLength = BitConverter.GetBytes(utData.Length);
                        //await klient.GetStream().WriteAsync(nameLength, 0, nameLength.Length);
                        //await klient.GetStream().WriteAsync(utData, 0, utData.Length
                        await klient.GetStream().WriteAsync(nr, 0, 4);
                                            
                        await klient.GetStream().WriteAsync(filData, 0, filData.Length);
                          
                    }
                    catch (Exception error) { MessageBox.Show(error.Message, "Klientfel"); return; }
                }
            }
        }
        public async void Lyssna()
        {

                    byte[] bufferTemp = new byte[1024];
                    byte[] buffer = null;
                    byte[] nr = new byte[4];
                    byte[] namn;
                    byte[] namnlängd = new byte[4];
                    List<byte> filen = new List<byte>();
                    int antalMottagnaByte = 0;
                    int filstorlek = 0;
                try
                {
                   

                    //while ( klient.Available > 0 )
                    //{
                    //    await klient.GetStream().ReadAsync(bufferTemp, 0, 1024);
                    //    filen.AddRange(bufferTemp);
                    //}


                    //await klient.GetStream().ReadAsync(namnlängd, 0, 4);
                    int namnlenght = BitConverter.ToInt32(namnlängd, 0);
                   // namn = new byte[namnlenght];

                    //await klient.GetStream().ReadAsync(namn, 0, namnlenght);

                    int n = await klient.GetStream().ReadAsync(nr, 0, 4);
                    
                   // string strängNamn = Encoding.Unicode.GetString(namn, 0, namn.Length);
                    filstorlek = BitConverter.ToInt32(nr, 0);
                    buffer = new byte[filstorlek];
                    klient.ReceiveBufferSize = filstorlek;

                    while (klient.Available > 0)
                    {
                        antalMottagnaByte += await klient.GetStream().ReadAsync(buffer, antalMottagnaByte, klient.Available);
                    }
                    DialogResult resultat = MessageBox.Show("Inkommande fil, Vill du ladda ner det?", "Ladda ner?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (resultat == DialogResult.Yes)
                    {
                        //saveFileDialog1.FileName = strängNamn;
                        //await utström.WriteAsync(buffer, 1, n);
                        //StreamWriter  skrivare = new StreamWriter(utström);
                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        {                       
                            File.WriteAllBytes(saveFileDialog1.FileName, buffer);
                        }
                }
                
                }
                catch(Exception error)
                {
                    string bufferinfo = "Buffert: " + ((buffer == null) ? "Buffer ej skapad" : buffer.Length.ToString());
                MessageBox.Show(error.Message + " Antalmotagnabytes " + antalMottagnaByte.ToString() + ", bufferstorleken " + bufferinfo + ", filstorlek: " + filstorlek.ToString() );
                return;
                }
                Lyssna();
                //btnTaEmot.Enabled = true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (!klient.Connected) Connect();
        }

        private void btnSendFile_Click(object sender, EventArgs e)
        {
            StartSending();
        }

        private void Klient_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult resultat = MessageBox.Show("Vill du avsluta", "stänger fönstret", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultat == DialogResult.No) e.Cancel = true; 
            if (klient != null) klient.Close();
        }

        private void btnTaEmot_Click(object sender, EventArgs e)
        {
            btnTaEmot.Enabled = false;
            Lyssna(); 
        }
    }
}
